using Godot;
using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>All drawing is done in code, so the game needs no image files.</summary>
public partial class GameWorld
{
    readonly Font _font = ThemeDB.FallbackFont;

    static float Rnd(int x, int y, int i)
    {
        double v = Math.Sin(x * 12.9898 + y * 78.233 + i * 37.719) * 43758.5453;
        return (float)(v - Math.Floor(v));
    }

    static Color RoleColor(Role r) => r switch
    {
        Role.Scout => new Color(0.25f, 0.85f, 0.35f),
        Role.Guardian => new Color(0.3f, 0.5f, 1f),
        Role.Engineer => new Color(0.97f, 0.8f, 0.2f),
        _ => new Color(0.75f, 0.35f, 0.95f),
    };

    static Color TypeColor(TileType t) => t switch
    {
        TileType.Forest => new Color(0.3f, 0.75f, 0.35f),
        TileType.Ruins => new Color(0.7f, 0.65f, 0.55f),
        TileType.Hills => new Color(0.85f, 0.75f, 0.35f),
        _ => new Color(0.55f, 0.4f, 0.85f),
    };

    bool OracleActive => Players.Any(p => p.Role == Role.Oracle);
    bool Vis(float x) => Chunks[ChunkOf(x)].Revealed;

    public override void _Draw()
    {
        if (Players.Count == 0) return;
        DrawBackdrop();

        DrawSetTransform(new Vector2(-_camX, 0), 0, Vector2.One);
        DrawZoneLabels();
        DrawTiles();
        foreach (var h in Hazards) if (h.Kind == Hazard.Drain && Vis(h.TileX * TS)) DrawPool(h);
        foreach (var f in Fruits) if (Vis(f.Pos.X)) DrawFruit(f);
        foreach (var b in Beacons) DrawBeaconEnt(b);
        foreach (var c in Critters) if (Vis(c.Pos.X)) DrawCritter(c);
        foreach (var p in Players) DrawPlayer(p);
        foreach (var pt in Particles)
            DrawCircle(pt.Pos, pt.Size * (pt.Life / pt.MaxLife), new Color(pt.Color, Mathf.Clamp(pt.Life / pt.MaxLife, 0f, 1f)));
        if (OracleActive) DrawOracleForecast();

        DrawSetTransform(Vector2.Zero, 0, Vector2.One);
        DrawHud();
    }

    // ================= BACKDROP =================
    void DrawBackdrop()
    {
        int stripes = 14;
        for (int i = 0; i < stripes; i++)
        {
            float t = i / (float)(stripes - 1);
            DrawRect(new Rect2(0, i * ViewH / stripes, ViewW, ViewH / stripes + 1), _sky.Darkened(0.25f * (1 - t)).Lightened(0.15f * t));
        }
        float cloudA = Mathf.Clamp(_sky.V - 0.25f, 0f, 0.6f);
        for (int i = 0; i < 7; i++)
        {
            float x = Mathf.PosMod(i * 260f - _camX * 0.12f + (float)_time * 8f, ViewW + 300f) - 150f;
            float y = 110 + (i * 37 % 110);
            var c = new Color(1, 1, 1, cloudA);
            DrawCircle(new Vector2(x, y), 22, c); DrawCircle(new Vector2(x + 24, y + 4), 18, c); DrawCircle(new Vector2(x - 24, y + 6), 16, c);
        }
        DrawHillLayer(0.2f, 0.66f, 70, _sky.Darkened(0.15f));
        DrawHillLayer(0.45f, 0.76f, 50, _sky.Darkened(0.3f));
    }

    void DrawHillLayer(float par, float baseY, float amp, Color col)
    {
        var pts = new List<Vector2>();
        for (float x = -20; x <= ViewW + 40; x += 40)
        {
            float wx = x + _camX * par;
            pts.Add(new Vector2(x, ViewH * baseY - amp * (0.5f + 0.5f * Mathf.Sin(wx / 170f)) - amp * 0.4f * Mathf.Sin(wx / 63f)));
        }
        pts.Add(new Vector2(ViewW + 40, ViewH));
        pts.Add(new Vector2(-20, ViewH));
        DrawColoredPolygon(pts.ToArray(), col);
    }

    // ================= WORLD =================
    void DrawZoneLabels()
    {
        for (int c = 0; c < NC; c++)
        {
            float x0 = c * CW * TS;
            if (x0 + CW * TS < _camX || x0 > _camX + ViewW) continue;
            var ch = Chunks[c];
            DrawLine(new Vector2(x0, 88), new Vector2(x0, H * TS), new Color(1, 1, 1, 0.07f), 1);
            if (ch.Revealed)
            {
                string lbl = $"Zone {c + 1}: {ch.Type} (cost {Difficulty(ch.Type)})" + (ch.Stabilized ? "  [STABLE]" : "");
                DrawString(_font, new Vector2(x0 + 8, 102), lbl, HorizontalAlignment.Left, -1, 13, new Color(1, 1, 1, 0.65f));
            }
            else
                DrawString(_font, new Vector2(x0, 300), "?", HorizontalAlignment.Center, CW * TS, 80, new Color(1, 1, 1, 0.12f));
        }
    }

    void DrawTiles()
    {
        int x0 = Math.Max(0, (int)(_camX / TS) - 1), x1 = Math.Min(W - 1, (int)((_camX + ViewW) / TS) + 1);
        for (int tx = x0; tx <= x1; tx++)
        {
            var ch = Chunks[tx / CW];
            for (int ty = 0; ty < H; ty++)
            {
                byte v = Tiles[tx, ty];
                if (v == 0) continue;
                var r = new Rect2(tx * TS, ty * TS, TS, TS);
                bool exposed = ty == 0 || Tiles[tx, ty - 1] == 0;

                if (!ch.Revealed)   // fog: dark silhouette only
                {
                    DrawRect(r, new Color(0.11f, 0.11f, 0.17f));
                    if (exposed) DrawRect(new Rect2(r.Position, new Vector2(TS, 3)), new Color(0.22f, 0.22f, 0.32f));
                    continue;
                }
                if (v == 3) { DrawThorns(r); continue; }

                Color baseC, topC;
                switch (ch.Type)
                {
                    case TileType.Forest: baseC = new Color(0.45f, 0.3f, 0.16f); topC = new Color(0.25f, 0.7f, 0.25f); break;
                    case TileType.Ruins: baseC = new Color(0.5f, 0.47f, 0.42f); topC = new Color(0.68f, 0.64f, 0.58f); break;
                    case TileType.Hills: baseC = new Color(0.6f, 0.45f, 0.22f); topC = new Color(0.78f, 0.7f, 0.3f); break;
                    default: baseC = new Color(0.22f, 0.18f, 0.32f); topC = new Color(0.4f, 0.32f, 0.6f); break;
                }
                DrawRect(r, baseC);
                if (exposed) DrawRect(new Rect2(r.Position, new Vector2(TS, 7)), topC);

                if (ch.Type == TileType.Ruins)
                {
                    DrawLine(r.Position + new Vector2(0, 16), r.Position + new Vector2(TS, 16), baseC.Darkened(0.3f), 1);
                    float off = (ty % 2 == 0) ? 10 : 22;
                    DrawLine(r.Position + new Vector2(off, 0), r.Position + new Vector2(off, 16), baseC.Darkened(0.3f), 1);
                    DrawLine(r.Position + new Vector2(32 - off, 16), r.Position + new Vector2(32 - off, 32), baseC.Darkened(0.3f), 1);
                }
                else if (Rnd(tx, ty, 1) > 0.7f)
                {
                    var sp = r.Position + new Vector2(6 + Rnd(tx, ty, 2) * 18, 12 + Rnd(tx, ty, 3) * 14);
                    if (ch.Type == TileType.Caverns)
                    {
                        float a = 0.5f + 0.4f * Mathf.Sin((float)_time * 2 + tx);
                        DrawCircle(sp, 2.5f, new Color(0.4f, 0.95f, 1f, a));
                    }
                    else DrawCircle(sp, 2f, baseC.Darkened(0.25f));
                }
                if (ch.Stabilized && exposed) DrawRect(new Rect2(r.Position, new Vector2(TS, 2)), new Color(0.4f, 0.9f, 1f));
                if (ch.Flash > 0) DrawRect(r, new Color(1, 1, 1, ch.Flash * 0.5f));
            }
        }
    }

    void DrawThorns(Rect2 r)
    {
        float pulse = 0.5f + 0.5f * Mathf.Sin((float)_time * 4f);
        DrawRect(r, new Color(0.3f, 0.16f, 0.08f));
        var col = new Color(0.95f, 0.55f + 0.15f * pulse, 0.15f);
        for (int k = 0; k < 2; k++)
        {
            float y = r.Position.Y + 4 + k * 16;
            DrawColoredPolygon(new[] { new Vector2(r.Position.X, y), new Vector2(r.Position.X - 9, y + 8), new Vector2(r.Position.X, y + 14) }, col);
            DrawColoredPolygon(new[] { new Vector2(r.End.X, y), new Vector2(r.End.X + 9, y + 8), new Vector2(r.End.X, y + 14) }, col);
        }
        DrawRect(new Rect2(r.Position.X + 10, r.Position.Y, 12, TS), new Color(0.5f, 0.28f, 0.1f));
    }

    void DrawPool(Haz h)
    {
        var r = new Rect2(h.TileX * TS, h.Row * TS - 14, TS * 2, 14);
        float pulse = 0.5f + 0.5f * Mathf.Sin((float)_time * 4f);
        DrawRect(new Rect2(r.Position.X - 4, r.Position.Y - 10, r.Size.X + 8, 24), new Color(0.7f, 0.2f, 0.9f, 0.12f + 0.1f * pulse));
        DrawRect(r, new Color(0.5f, 0.1f, 0.6f, 0.95f));
        DrawRect(new Rect2(r.Position, new Vector2(r.Size.X, 3)), new Color(0.85f, 0.4f, 1f));
        for (int i = 0; i < 4; i++)   // bubbles
        {
            float t = Mathf.PosMod((float)_time * 0.9f + i * 0.27f, 1f);
            DrawCircle(new Vector2(r.Position.X + 8 + i * 15, r.Position.Y + 12 - t * 22), 2.5f * (1 - t) + 1f, new Color(0.9f, 0.6f, 1f, 1 - t));
        }
    }

    void DrawFruit(Fruit f)
    {
        var p = f.Pos + new Vector2(0, Mathf.Sin((float)_time * 3f + f.Phase) * 3f);
        DrawCircle(p, 9, new Color(0.85f, 0.15f, 0.15f));
        DrawCircle(p + new Vector2(-3, -3), 3, new Color(1f, 0.6f, 0.6f));
        DrawColoredPolygon(new[] { p + new Vector2(0, -9), p + new Vector2(8, -14), p + new Vector2(5, -7) }, new Color(0.2f, 0.7f, 0.2f));
    }

    void DrawCritter(Critter c)
    {
        float squish = Mathf.Sin((float)_time * 10f + c.Pos.X) * 1.5f;
        var cen = c.Center + new Vector2(0, 2);
        DrawCircle(cen + new Vector2(0, -2), 12 + squish * 0.3f, new Color(0.6f, 0.2f, 0.35f));
        DrawRect(new Rect2(c.Pos.X + 1, c.Pos.Y + 14, 22, 6), new Color(0.6f, 0.2f, 0.35f));
        DrawRect(new Rect2(c.Pos.X + 3 + squish, c.Pos.Y + 17, 7, 4), new Color(0.2f, 0.08f, 0.12f));
        DrawRect(new Rect2(c.Pos.X + 14 - squish, c.Pos.Y + 17, 7, 4), new Color(0.2f, 0.08f, 0.12f));
        DrawCircle(cen + new Vector2(-4, -4), 3.5f, Colors.White);
        DrawCircle(cen + new Vector2(4, -4), 3.5f, Colors.White);
        DrawCircle(cen + new Vector2(-4 + c.Dir, -4), 1.5f, Colors.Black);
        DrawCircle(cen + new Vector2(4 + c.Dir, -4), 1.5f, Colors.Black);
        DrawLine(cen + new Vector2(-8, -10), cen + new Vector2(-1, -7), Colors.Black, 2);
        DrawLine(cen + new Vector2(8, -10), cen + new Vector2(1, -7), Colors.Black, 2);
    }

    void DrawBeaconEnt(BeaconEnt b)
    {
        var ch = Chunks[b.Chunk];
        if (!ch.Revealed && b.State != BeaconState.Active) return;
        float pulse = 0.5f + 0.5f * Mathf.Sin((float)_time * 3f);
        Color orb = b.State switch
        {
            BeaconState.Active => new Color(0.4f, 1f, 1f),
            BeaconState.Corrupted => new Color(0.95f, 0.2f, 0.3f),
            _ => new Color(0.55f, 0.65f, 0.95f),
        };
        var bp = new Vector2(b.X, b.BaseY);
        var top = bp + new Vector2(0, -78);

        if (b.State == BeaconState.Active)
            DrawRect(new Rect2(b.X - 7, 0, 14, top.Y), new Color(orb, 0.10f + 0.05f * pulse));   // light beam

        DrawRect(new Rect2(bp.X - 22, bp.Y - 10, 44, 10), new Color(0.3f, 0.3f, 0.36f));
        DrawRect(new Rect2(bp.X - 8, bp.Y - 64, 16, 56), new Color(0.58f, 0.58f, 0.64f));
        DrawRect(new Rect2(bp.X - 13, bp.Y - 70, 26, 8), new Color(0.35f, 0.35f, 0.42f));

        if (b.State == BeaconState.Active)
        {
            DrawCircle(top, 30 + 6 * pulse, new Color(orb, 0.12f));
            DrawCircle(top, 20, new Color(orb, 0.3f));
            for (int i = 0; i < 6; i++)
            {
                float a = (float)_time * 2f + i * Mathf.Tau / 6f;
                DrawCircle(top + new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * 32, 3f, orb);
            }
        }
        DrawCircle(top, 12, new Color(orb, b.State == BeaconState.Inactive ? 0.55f + 0.3f * pulse : 1f));
        if (b.State == BeaconState.Corrupted)
        {
            DrawLine(bp + new Vector2(-5, -58), bp + new Vector2(3, -36), new Color(0.2f, 0, 0.05f), 2);
            DrawLine(bp + new Vector2(3, -36), bp + new Vector2(-4, -16), new Color(0.2f, 0, 0.05f), 2);
        }

        if (b.State != BeaconState.Active)   // interaction prompt
            foreach (var p in Players)
                if (Math.Abs(p.Center.X - b.X) < 70 && Math.Abs(p.Pos.Y + p.Size.Y - b.BaseY) < 70)
                {
                    string key = OS.GetKeycodeString(p.Bind.Interact[0]);
                    string act = b.State == BeaconState.Inactive ? "Activate (2)" : "Purge (3)";
                    DrawString(_font, new Vector2(b.X - 60, top.Y - 24), $"[{key}] {act}", HorizontalAlignment.Center, 120, 14, Colors.White);
                    break;
                }
    }

    void DrawPlayer(Player p)
    {
        float a = (p.Invuln > 0 && ((int)(_time * 20) % 2 == 0)) ? 0.35f : 1f;
        var f = new Vector2(p.Pos.X + p.Size.X / 2f, p.Pos.Y + p.Size.Y);
        var col = RoleColor(p.Role);
        if (p.Exhausted) col = col.Lerp(new Color(0.5f, 0.5f, 0.5f), 0.7f);
        col.A = a;
        var dark = new Color(col.R * 0.6f, col.G * 0.6f, col.B * 0.6f, a);
        var legC = new Color(0.2f, 0.2f, 0.35f, a);
        var skin = new Color(0.97f, 0.8f, 0.65f, a);
        int fd = p.Facing;

        float run = !p.OnGround ? 6f : (Math.Abs(p.Vel.X) > 20 ? Mathf.Sin(p.Anim * 12f) * 5f : 0f);
        DrawCircle(new Vector2(f.X, f.Y + 1), 9, new Color(0, 0, 0, 0.25f * a));
        DrawRect(new Rect2(f.X - 8 + run, f.Y - 9, 6, 9), legC);
        DrawRect(new Rect2(f.X + 2 - run, f.Y - 9, 6, 9), legC);
        DrawRect(new Rect2(f.X - 8, f.Y - 21, 16, 13), col);
        DrawRect(new Rect2(f.X + (fd > 0 ? 6 : -11), f.Y - 19 + (p.OnGround ? 0 : -4), 5, 9), dark);   // arm
        DrawCircle(new Vector2(f.X, f.Y - 27), 8, skin);
        DrawCircle(new Vector2(f.X + 4 * fd, f.Y - 28), 1.7f, new Color(0, 0, 0, a));

        switch (p.Role)
        {
            case Role.Scout:
                DrawRect(new Rect2(f.X - 8, f.Y - 37, 16, 6), dark);
                DrawRect(new Rect2(f.X + (fd > 0 ? 3 : -13), f.Y - 32, 10, 3), dark);
                DrawLine(new Vector2(f.X - 4 * fd, f.Y - 37), new Vector2(f.X - 11 * fd, f.Y - 44), new Color(1, 0.9f, 0.3f, a), 2);
                break;
            case Role.Guardian:
                DrawRect(new Rect2(f.X - 9, f.Y - 37, 18, 8), dark);
                DrawCircle(new Vector2(f.X - 2 * fd, f.Y - 15), 6, new Color(0.8f, 0.85f, 1f, a));
                DrawCircle(new Vector2(f.X - 2 * fd, f.Y - 15), 3, dark);
                break;
            case Role.Engineer:
                DrawRect(new Rect2(f.X - 7, f.Y - 38, 14, 7), new Color(1f, 0.85f, 0.15f, a));
                DrawRect(new Rect2(f.X - 10, f.Y - 32, 20, 3), new Color(0.9f, 0.7f, 0.1f, a));
                break;
            default:   // Oracle: wizard hat
                DrawColoredPolygon(new[] { new Vector2(f.X - 10, f.Y - 31), new Vector2(f.X + 2 * fd, f.Y - 50), new Vector2(f.X + 10, f.Y - 31) }, dark);
                DrawCircle(new Vector2(f.X + 2 * fd, f.Y - 49), 2.5f, new Color(1f, 0.95f, 0.4f, a));
                break;
        }

        DrawString(_font, new Vector2(f.X - 20, f.Y - 54), p.Name, HorizontalAlignment.Center, 40, 13, new Color(1, 1, 1, 0.9f));
        if (p.Exhausted) DrawString(_font, new Vector2(f.X - 20, f.Y - 66), "zzz", HorizontalAlignment.Center, 40, 14, new Color(1, 1, 0.6f));
    }

    void DrawOracleForecast()
    {
        foreach (var s in NextShifts)
        {
            float x0 = s.chunk * CW * TS;
            DrawRect(new Rect2(x0 + 8, 112, CW * TS - 16, 22), new Color(0.5f, 0.25f, 0.8f, 0.6f));
            DrawString(_font, new Vector2(x0 + 8, 128), $"ORACLE: shifts to {s.type}", HorizontalAlignment.Center, CW * TS - 16, 13, Colors.White);
        }
        foreach (var h in NextHazards)
        {
            float x0 = h.chunk * CW * TS;
            DrawRect(new Rect2(x0 + 8, 138, CW * TS - 16, 22), new Color(0.9f, 0.4f, 0.1f, 0.6f));
            DrawString(_font, new Vector2(x0 + 8, 154), $"ORACLE: {h.kind} hazard coming", HorizontalAlignment.Center, CW * TS - 16, 13, Colors.White);
        }
    }

    // ================= HUD =================
    void DrawHud()
    {
        DrawRect(new Rect2(0, 0, ViewW, 78), new Color(0, 0, 0, 0.6f));

        for (int i = 0; i < Players.Count; i++)
        {
            var p = Players[i];
            float x = i == 0 ? 12 : ViewW - 262;
            DrawString(_font, new Vector2(x, 20), $"{p.Name}  {p.Role}", HorizontalAlignment.Left, -1, 17, RoleColor(p.Role));
            DrawRect(new Rect2(x, 28, 240, 16), new Color(0.15f, 0.15f, 0.2f));
            float ratio = Mathf.Clamp(p.Energy / MaxEnergy, 0f, 1f);
            DrawRect(new Rect2(x, 28, 240 * ratio, 16), new Color(1f - ratio, 0.35f + 0.55f * ratio, 0.2f));
            DrawRect(new Rect2(x, 28, 240, 16), new Color(1, 1, 1, 0.5f), false, 1);
            DrawString(_font, new Vector2(x, 42), $"Energy {p.Energy:0.0}/{MaxEnergy:0}", HorizontalAlignment.Center, 240, 12, Colors.White);
            string info = $"Beacons activated: {p.Beacons}" + (p.Exhausted ? "   EXHAUSTED" : "");
            DrawString(_font, new Vector2(x, 62), info, HorizontalAlignment.Left, -1, 14, new Color(1, 1, 1, 0.85f));
        }

        // center: turn / phase / timer / minimap
        float cx = 300, cw = ViewW - 600;
        int active = Beacons.Count(b => b.State == BeaconState.Active);
        int corrupt = Beacons.Count(b => b.State == BeaconState.Corrupted);
        DrawString(_font, new Vector2(cx, 20), $"TURN {Math.Min(_turn, MaxTurns)}/{MaxTurns}  -  {_phase}   |   Beacons {active}/{BeaconCount}" + (corrupt > 0 ? $"  ({corrupt} corrupted)" : ""),
            HorizontalAlignment.Center, cw, 16, Colors.White);
        DrawRect(new Rect2(cx, 26, cw, 6), new Color(0.2f, 0.2f, 0.25f));
        DrawRect(new Rect2(cx, 26, cw * Mathf.Clamp(_turnT / TurnSeconds, 0f, 1f), 6), new Color(0.95f, 0.8f, 0.3f));
        foreach (float m in new[] { ShiftEnd, HazardAt, RestAt })
            DrawRect(new Rect2(cx + cw * m / TurnSeconds - 1, 24, 2, 10), new Color(1, 1, 1, 0.8f));

        float cell = cw / NC;
        for (int c = 0; c < NC; c++)
        {
            var ch = Chunks[c];
            var r = new Rect2(cx + c * cell + 1, 40, cell - 2, 22);
            DrawRect(r, ch.Revealed ? TypeColor(ch.Type).Darkened(0.2f) : new Color(0.14f, 0.14f, 0.2f));
            if (ch.Stabilized) DrawRect(r, new Color(0.4f, 0.9f, 1f), false, 2);
            if (ch.Revealed && ch.HasBeacon)
            {
                var bs = Beacons.First(b => b.Chunk == c).State;
                DrawCircle(r.Position + new Vector2(cell / 2 - 1, 6), 4, bs == BeaconState.Active ? new Color(0.4f, 1f, 1f) : bs == BeaconState.Corrupted ? new Color(1f, 0.2f, 0.3f) : Colors.White);
            }
            if (OracleActive && NextShifts.Any(s => s.chunk == c))
                DrawColoredPolygon(new[] { r.Position + new Vector2(cell / 2 - 4, 28), r.Position + new Vector2(cell / 2 + 2, 28), r.Position + new Vector2(cell / 2 - 1, 23) }, new Color(0.8f, 0.5f, 1f));
        }
        foreach (var p in Players)
            DrawCircle(new Vector2(cx + p.Center.X / (W * TS) * cw, 56), 4, RoleColor(p.Role).Lightened(0.2f));

        // toasts
        for (int i = 0; i < Toasts.Count; i++)
        {
            var t = Toasts[Toasts.Count - 1 - i];
            float y = ViewH - 40 - i * 22;
            float alpha = Mathf.Clamp(t.T, 0f, 1f);
            DrawRect(new Rect2(10, y - 15, 640, 20), new Color(0, 0, 0, 0.45f * alpha));
            DrawString(_font, new Vector2(16, y), t.Text, HorizontalAlignment.Left, 630, 14, new Color(1, 1, 1, alpha));
        }

        string hint = _mode == GameMode.Solo
            ? "A/D or Arrows: move   W/Space/Up: jump   E/Z: Explore   F/X: Interact   R: restart   Esc: menu"
            : "P1: A/D W E(explore) F(interact) Q(give)    P2: Arrows, ,(explore) .(interact) /(give)    R: restart  Esc: menu";
        DrawString(_font, new Vector2(10, ViewH - 10), hint, HorizontalAlignment.Left, -1, 13, new Color(1, 1, 1, 0.7f));

        if (_phaseBanner > 0 && _state == GameState.Playing && _phase != "PLAYER PHASE")
            DrawString(_font, new Vector2(0, 200), _phase, HorizontalAlignment.Center, ViewW, 40, new Color(1, 0.95f, 0.5f, Mathf.Clamp(_phaseBanner, 0f, 1f)));

        if (_state != GameState.Playing)
        {
            bool win = _state == GameState.Victory;
            DrawRect(new Rect2(0, 0, ViewW, ViewH), new Color(0, 0, 0, 0.55f));
            DrawString(_font, new Vector2(0, 280), win ? "VICTORY!" : "DEFEAT", HorizontalAlignment.Center, ViewW, 72, win ? new Color(0.6f, 1f, 0.7f) : new Color(1f, 0.5f, 0.5f));
            DrawString(_font, new Vector2(0, 330), _endReason, HorizontalAlignment.Center, ViewW, 22, Colors.White);
            DrawString(_font, new Vector2(0, 380), "R: play again     Esc: menu", HorizontalAlignment.Center, ViewW, 20, new Color(1, 1, 1, 0.8f));
        }
    }
}
