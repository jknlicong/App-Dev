using Godot;
using System;
using System.Collections.Generic;
using System.Linq;

/// <summary>
/// Side-scrolling platformer version of the lab game.
/// The level is 14 "tiles" (zones) of 10 columns each. Every TurnSeconds a new turn begins:
/// Shift Phase -> Player Phase -> Hazard Phase -> Rest Phase.
/// This file = simulation. GameWorldDraw.cs = rendering.
/// </summary>
public partial class GameWorld : Node2D
{
    // ---------- level ----------
    public const int TS = 32;          // pixels per block
    public const int CW = 10;          // columns per zone
    public const int NC = 14;          // number of zones
    public const int W = CW * NC;      // level width in blocks
    public const int H = 20;           // level height in blocks
    public const int GR = 16;          // ground row
    public const float ViewW = 1152f, ViewH = 648f;

    // ---------- tuning ----------
    const float Gravity = 1800f, RunSpeed = 210f, JumpV = -690f;
    const float TurnSeconds = 12f;
    const int MaxTurns = 10;                       // turn limit (lab rule)
    const float StartEnergy = 16f, MaxEnergy = 20f;
    const float ShiftEnd = 0.9f, HazardAt = 9.5f, RestAt = 11f;   // phase timings inside a turn
    const int BeaconCount = 3;

    public event Action BackToMenu;

    // ---------- state ----------
    readonly byte[,] Tiles = new byte[W, H];       // 0 air, 1 solid, 3 thorn barrier
    readonly int[] GroundTop = new int[W];         // row of ground surface per column (H = pit)
    readonly Chunk[] Chunks = new Chunk[NC];
    readonly List<Player> Players = new();
    readonly List<Critter> Critters = new();
    readonly List<Fruit> Fruits = new();
    readonly List<Haz> Hazards = new();
    readonly List<BeaconEnt> Beacons = new();
    readonly List<Particle> Particles = new();
    readonly List<ToastMsg> Toasts = new();
    readonly List<(int chunk, TileType type)> NextShifts = new();
    readonly List<(int chunk, Hazard kind)> NextHazards = new();

    GameMode _mode;
    List<Role> _roles = new();
    GameState _state = GameState.Playing;
    string _endReason = "";
    int _turn = 1;
    float _turnT;
    bool _hazardDone, _restDone;
    string _phase = "";
    float _phaseBanner;
    float _camX;
    double _time;
    Color _sky = new Color(0.45f, 0.75f, 0.95f);
    readonly Random _rng = new();

    // ---------- input ----------
    static readonly Key[] AllKeys =
    {
        Key.A, Key.D, Key.W, Key.E, Key.F, Key.Q, Key.Space, Key.Left, Key.Right, Key.Up,
        Key.Z, Key.X, Key.Comma, Key.Period, Key.Slash, Key.R, Key.Escape
    };
    readonly HashSet<Key> _now = new(), _prev = new();

    void PollKeys()
    {
        _prev.Clear();
        foreach (var k in _now) _prev.Add(k);
        _now.Clear();
        foreach (var k in AllKeys) if (Input.IsKeyPressed(k)) _now.Add(k);
    }
    bool Held(params Key[] ks) { foreach (var k in ks) if (_now.Contains(k)) return true; return false; }
    bool Tapped(params Key[] ks) { foreach (var k in ks) if (_now.Contains(k) && !_prev.Contains(k)) return true; return false; }

    // =====================================================================
    //  SETUP
    // =====================================================================
    public void Start(GameMode mode, List<Role> roles)
    {
        _mode = mode;
        _roles = new List<Role>(roles);
        _state = GameState.Playing;
        _endReason = "";
        Players.Clear(); Critters.Clear(); Fruits.Clear(); Hazards.Clear();
        Beacons.Clear(); Particles.Clear(); Toasts.Clear();
        _turn = 1; _turnT = 0; _hazardDone = _restDone = false; _phase = ""; _camX = 0;

        var types = Enum.GetValues<TileType>();
        for (int c = 0; c < NC; c++)
            Chunks[c] = new Chunk { Type = c == 0 ? TileType.Forest : types[_rng.Next(types.Length)] };
        Chunks[0].Revealed = true;

        // three Ancient Beacons, spread along the level
        int[] bc = { _rng.Next(3, 6), _rng.Next(6, 10), _rng.Next(10, 14) };
        foreach (int c in bc)
        {
            Chunks[c].HasBeacon = true;
            Beacons.Add(new BeaconEnt { Chunk = c, X = (c * CW + CW / 2) * TS + TS / 2f, BaseY = GR * TS });
        }

        for (int c = 0; c < NC; c++) { GenerateChunk(c); GenerateFruits(c); GenerateCritters(c); }

        var b1 = _mode == GameMode.Solo
            ? new Bind { Left = new[] { Key.A, Key.Left }, Right = new[] { Key.D, Key.Right }, Jump = new[] { Key.W, Key.Space, Key.Up }, Explore = new[] { Key.E, Key.Z }, Interact = new[] { Key.F, Key.X }, Give = new[] { Key.Q } }
            : new Bind { Left = new[] { Key.A }, Right = new[] { Key.D }, Jump = new[] { Key.W, Key.Space }, Explore = new[] { Key.E }, Interact = new[] { Key.F }, Give = new[] { Key.Q } };
        var b2 = new Bind { Left = new[] { Key.Left }, Right = new[] { Key.Right }, Jump = new[] { Key.Up }, Explore = new[] { Key.Comma }, Interact = new[] { Key.Period }, Give = new[] { Key.Slash } };

        for (int i = 0; i < _roles.Count; i++)
        {
            var p = new Player
            {
                Name = $"P{i + 1}", Role = _roles[i], Energy = StartEnergy, Bind = i == 0 ? b1 : b2,
                Size = new Vector2(20, 30), Pos = new Vector2((2 + i * 1.3f) * TS, GR * TS - 31)
            };
            p.SafePos = p.Pos;
            Players.Add(p);
        }

        Toast(_mode switch
        {
            GameMode.Solo => "Find and activate all 3 Ancient Beacons before turn 10!",
            GameMode.Coop => "Co-op: activate all 3 Beacons before turn 10!",
            _ => "Race! First to activate 2 Beacons wins!"
        });
        PlanNext();
        ShiftPhase();
    }

    // =====================================================================
    //  LEVEL GENERATION  (each zone = one lab "tile" that can change type)
    // =====================================================================
    void GenerateChunk(int c)
    {
        var ch = Chunks[c];
        int x0 = c * CW;
        var top = new int[CW];
        for (int i = 0; i < CW; i++) top[i] = GR;
        var plats = new List<(int col, int row, int w)>();
        var ceil = new List<(int col, int len)>();

        switch (ch.Type)
        {
            case TileType.Forest:
            {
                int n = _rng.Next(1, 3);
                for (int k = 0; k < n; k++)
                    plats.Add((_rng.Next(1, CW - 5), GR - 3, _rng.Next(3, 5)));
                if (c != 0)
                {
                    int bumps = _rng.Next(0, 3);
                    for (int k = 0; k < bumps; k++) { int col = _rng.Next(2, CW - 3); top[col] = GR - 1; top[col + 1] = GR - 1; }
                }
                break;
            }
            case TileType.Ruins:
            {
                int np = _rng.Next(1, 3);
                int col = 2;
                for (int k = 0; k < np; k++)
                {
                    col = _rng.Next(2, CW - 4);
                    int h = _rng.Next(2, 4);
                    top[col] = GR - h; top[col + 1] = GR - h;
                    plats.Add((Math.Max(0, col - 1), GR - h - 2, 3));
                }
                break;
            }
            case TileType.Hills:
            {
                int h = _rng.Next(2, 4);
                for (int i = 0; i < CW; i++) top[i] = GR - (int)Math.Round(h * Math.Sin(Math.PI * i / (CW - 1)));
                plats.Add((_rng.Next(3, 6), GR - h - 3, 3));
                break;
            }
            default:   // Caverns: pits + ceiling spikes
            {
                int pits = _rng.Next(1, 3), cur = 2;
                for (int k = 0; k < pits; k++)
                {
                    int w = _rng.Next(3, 5);
                    int col = cur + _rng.Next(0, 2);
                    if (col + w > CW - 2) break;
                    for (int i = 0; i < w; i++) top[col + i] = H;
                    if (_rng.Next(2) == 0) plats.Add((col + 1, GR - 3, 2));
                    cur = col + w + 2;
                }
                int sp = _rng.Next(3, 6);
                for (int k = 0; k < sp; k++) ceil.Add((_rng.Next(0, CW), _rng.Next(1, 5)));
                break;
            }
        }

        if (ch.HasBeacon)   // keep a flat area around the Beacon
        {
            for (int i = 3; i <= 7; i++) top[i] = GR;
            plats.RemoveAll(p => p.col + p.w > 3 && p.col <= 7);
        }

        for (int i = 0; i < CW; i++)
        {
            GroundTop[x0 + i] = top[i];
            for (int y = 0; y < H; y++) Tiles[x0 + i, y] = (byte)(top[i] < H && y >= top[i] ? 1 : 0);
        }
        foreach (var p in plats) for (int k = 0; k < p.w; k++) Tiles[x0 + p.col + k, p.row] = 1;
        foreach (var e in ceil) for (int y = 0; y < e.len; y++) Tiles[x0 + e.col, y] = 1;
    }

    void GenerateFruits(int c)
    {
        Fruits.RemoveAll(f => ChunkOf(f.Pos.X) == c);
        int n = _rng.Next(2, 4);
        for (int i = 0; i < n; i++)
        {
            int tx = c * CW + _rng.Next(1, CW - 1);
            int r = 6;
            while (r < H && Tiles[tx, r] == 0) r++;
            if (r >= H) continue;
            Fruits.Add(new Fruit { Pos = new Vector2(tx * TS + TS / 2f, r * TS - 20), Phase = (float)_rng.NextDouble() * 6f });
        }
    }

    void GenerateCritters(int c)
    {
        Critters.RemoveAll(k => ChunkOf(k.Pos.X) == c);
        if (c == 0 || Chunks[c].HasBeacon) return;
        int n = Chunks[c].Type == TileType.Caverns ? 2 : 1;
        for (int i = 0; i < n; i++)
            for (int tries = 0; tries < 10; tries++)
            {
                int tx = c * CW + 1 + _rng.Next(0, CW - 2);
                if (GroundTop[tx] >= H) continue;
                Critters.Add(new Critter { Size = new Vector2(24, 20), Pos = new Vector2(tx * TS + 4, GroundTop[tx] * TS - 21), Dir = _rng.Next(2) == 0 ? -1 : 1 });
                break;
            }
    }

    static int ChunkOf(float x) => Math.Clamp((int)(x / (CW * TS)), 0, NC - 1);
    static int Difficulty(TileType t) => t == TileType.Forest ? 1 : t == TileType.Caverns ? 3 : 2;

    // =====================================================================
    //  COLLISION
    // =====================================================================
    bool SolidAt(int tx, int ty)
    {
        if (tx < 0 || tx >= W) return true;     // world walls on the left and right
        if (ty < 0 || ty >= H) return false;
        return Tiles[tx, ty] != 0;
    }

    bool Overlaps(Body b)
    {
        int x0 = (int)Math.Floor(b.Pos.X / TS), x1 = (int)Math.Floor((b.Pos.X + b.Size.X - 0.01f) / TS);
        int y0 = (int)Math.Floor(b.Pos.Y / TS), y1 = (int)Math.Floor((b.Pos.Y + b.Size.Y - 0.01f) / TS);
        for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) if (SolidAt(x, y)) return true;
        return false;
    }

    void MoveBody(Body b, float dt)
    {
        // X axis
        b.HitWall = false;
        b.Pos.X += b.Vel.X * dt;
        int y0 = (int)Math.Floor(b.Pos.Y / TS), y1 = (int)Math.Floor((b.Pos.Y + b.Size.Y - 0.01f) / TS);
        if (b.Vel.X > 0)
        {
            int tx = (int)Math.Floor((b.Pos.X + b.Size.X - 0.01f) / TS);
            for (int ty = y0; ty <= y1; ty++)
                if (SolidAt(tx, ty)) { b.Pos.X = tx * TS - b.Size.X; b.Vel.X = 0; b.HitWall = true; break; }
        }
        else if (b.Vel.X < 0)
        {
            int tx = (int)Math.Floor(b.Pos.X / TS);
            for (int ty = y0; ty <= y1; ty++)
                if (SolidAt(tx, ty)) { b.Pos.X = (tx + 1) * TS; b.Vel.X = 0; b.HitWall = true; break; }
        }

        // Y axis
        b.OnGround = false;
        b.Pos.Y += b.Vel.Y * dt;
        int x0 = (int)Math.Floor(b.Pos.X / TS), x1 = (int)Math.Floor((b.Pos.X + b.Size.X - 0.01f) / TS);
        if (b.Vel.Y > 0)
        {
            int ty = (int)Math.Floor((b.Pos.Y + b.Size.Y - 0.01f) / TS);
            for (int tx = x0; tx <= x1; tx++)
                if (SolidAt(tx, ty)) { b.Pos.Y = ty * TS - b.Size.Y; b.Vel.Y = 0; b.OnGround = true; break; }
        }
        else if (b.Vel.Y < 0)
        {
            int ty = (int)Math.Floor(b.Pos.Y / TS);
            for (int tx = x0; tx <= x1; tx++)
                if (SolidAt(tx, ty)) { b.Pos.Y = (ty + 1) * TS; b.Vel.Y = 0; break; }
        }
    }

    void Unstick(Body b)
    {
        int guard = 0;
        while (Overlaps(b) && guard++ < 90) b.Pos.Y -= 4;
    }

    // =====================================================================
    //  MAIN LOOP
    // =====================================================================
    public override void _Process(double delta)
    {
        float dt = (float)Math.Min(delta, 1.0 / 30.0);
        _time += dt;
        PollKeys();

        if (Tapped(Key.Escape)) { BackToMenu?.Invoke(); return; }
        if (Tapped(Key.R)) { Start(_mode, _roles); return; }

        if (_state == GameState.Playing) Simulate(dt);

        UpdateParticles(dt);
        foreach (var t in Toasts) t.T -= dt;
        Toasts.RemoveAll(t => t.T <= 0);
        _phaseBanner = Math.Max(0, _phaseBanner - dt);
        foreach (var ch in Chunks) ch.Flash = Math.Max(0, ch.Flash - dt * 1.5f);
        UpdateCamera(dt);
        QueueRedraw();
    }

    void Simulate(float dt)
    {
        _turnT += dt;
        UpdatePhase();
        if (_state != GameState.Playing) return;

        foreach (var p in Players) UpdatePlayer(p, dt);
        foreach (var c in Critters) UpdateCritter(c, dt);
        Critters.RemoveAll(c => c.Pos.Y > H * TS + 100);
        Contacts();
        CheckEnd();
    }

    void UpdatePhase()
    {
        string phase = _turnT < ShiftEnd ? "SHIFT PHASE" : _turnT < HazardAt ? "PLAYER PHASE" : _turnT < RestAt ? "HAZARD PHASE" : "REST PHASE";
        if (phase != _phase) { _phase = phase; _phaseBanner = 1.1f; }

        if (!_hazardDone && _turnT >= HazardAt) { _hazardDone = true; HazardPhase(); if (CheckEnd()) return; }
        if (!_restDone && _turnT >= RestAt) { _restDone = true; RestPhase(); }
        if (_turnT >= TurnSeconds)
        {
            _turn++;
            if (_turn > MaxTurns) { Finish(GameState.Defeat, "The turn limit was reached."); return; }
            _turnT = 0; _hazardDone = _restDone = false;
            ShiftPhase();
        }
    }

    // =====================================================================
    //  PLAYER
    // =====================================================================
    void UpdatePlayer(Player p, float dt)
    {
        var b = p.Bind;
        p.Exhausted = p.Energy <= 0.01f;
        p.Invuln = Math.Max(0, p.Invuln - dt);
        p.Stun = Math.Max(0, p.Stun - dt);
        p.ActCd = Math.Max(0, p.ActCd - dt);

        float dir = 0;
        if (!p.Exhausted && p.Stun <= 0)
        {
            if (Held(b.Left)) dir -= 1;
            if (Held(b.Right)) dir += 1;
        }
        if (p.Stun <= 0)
            p.Vel.X = Mathf.MoveToward(p.Vel.X, dir * RunSpeed, (p.OnGround ? 2400f : 1300f) * dt);
        if (dir != 0) p.Facing = (int)dir;

        // jumping (coyote time + jump buffer + variable height)
        p.Coyote = p.OnGround ? 0.1f : p.Coyote - dt;
        if (Tapped(b.Jump)) p.JumpBuf = 0.12f; else p.JumpBuf -= dt;
        if (!p.Exhausted && p.Stun <= 0 && p.JumpBuf > 0 && p.Coyote > 0)
        {
            p.Vel.Y = JumpV; p.Coyote = 0; p.JumpBuf = 0;
            Burst(new Vector2(p.Center.X, p.Pos.Y + p.Size.Y), new Color(1, 1, 1, 0.6f), 5, 60);
        }
        if (!Held(b.Jump) && p.Stun <= 0 && p.Vel.Y < -240f) p.Vel.Y = -240f;

        // Energy drain: moving through harder terrain costs more (lab rule: movement cost = terrain difficulty)
        var zone = Chunks[ChunkOf(p.Center.X)];
        float rate = Math.Abs(p.Vel.X) > 20f ? 0.28f * Difficulty(zone.Type) : 0.08f;
        p.Energy = Math.Max(0, p.Energy - rate * dt);

        p.Vel.Y = Math.Min(p.Vel.Y + Gravity * dt, 900f);
        MoveBody(p, dt);
        p.Anim += dt * (Math.Abs(p.Vel.X) / RunSpeed);

        // remember a safe spot (for pit respawns)
        p.SafeT -= dt;
        if (p.OnGround && p.SafeT <= 0 && FootSupport(p)) { p.SafePos = p.Pos; p.SafeT = 0.4f; }

        if (p.Pos.Y > H * TS + 60)   // fell into a pit
        {
            p.Pos = p.SafePos; p.Vel = Vector2.Zero;
            Unstick(p);
            Hurt(p, 2, false, 0, true);
            p.Invuln = 1.5f;
            Toast($"{p.Name} fell into a pit! Energy lost.");
        }

        if (!p.Exhausted && p.ActCd <= 0)
        {
            if (Tapped(b.Explore)) { DoExplore(p); p.ActCd = 0.3f; }
            else if (Tapped(b.Interact)) { DoInteract(p); p.ActCd = 0.3f; }
        }
        if (_mode == GameMode.Coop && Tapped(b.Give)) DoGive(p);
    }

    bool FootSupport(Player p)
    {
        int ty = (int)Math.Floor((p.Pos.Y + p.Size.Y + 2) / TS);
        return SolidAt((int)Math.Floor((p.Pos.X + 2) / TS), ty) && SolidAt((int)Math.Floor((p.Pos.X + p.Size.X - 2) / TS), ty);
    }

    void Hurt(Player p, float amt, bool knock, int dir, bool force = false)
    {
        if (!force && p.Invuln > 0) return;
        if (p.Role == Role.Guardian) amt *= 0.5f;     // Guardian: reduced hazard damage
        p.Energy = Math.Max(0, p.Energy - amt);
        p.Invuln = 1.2f;
        if (knock) { p.Stun = 0.25f; p.Vel = new Vector2(-dir * 220f, -300f); }
        Burst(p.Center, new Color(1f, 0.3f, 0.3f), 8, 140);
    }

    void UpdateCritter(Critter c, float dt)
    {
        c.Vel.Y = Math.Min(c.Vel.Y + Gravity * dt, 900f);
        c.Vel.X = c.Dir * 45f;
        MoveBody(c, dt);
        if (c.HitWall) c.Dir = -c.Dir;
        else if (c.OnGround)
        {
            int tx = (int)Math.Floor((c.Pos.X + (c.Dir > 0 ? c.Size.X + 3 : -3)) / TS);
            int ty = (int)Math.Floor((c.Pos.Y + c.Size.Y + 3) / TS);
            if (!SolidAt(tx, ty)) c.Dir = -c.Dir;
        }
    }

    void Contacts()
    {
        foreach (var p in Players)
        {
            var pr = new Rect2(p.Pos, p.Size);

            for (int i = Fruits.Count - 1; i >= 0; i--)   // fruit = Energy
            {
                var f = Fruits[i];
                if (new Rect2(f.Pos - new Vector2(10, 10), new Vector2(20, 20)).Intersects(pr))
                {
                    p.Energy = Math.Min(MaxEnergy, p.Energy + 2f);
                    Burst(f.Pos, new Color(1f, 0.4f, 0.4f), 8, 120);
                    Fruits.RemoveAt(i);
                }
            }

            for (int i = Critters.Count - 1; i >= 0; i--)   // stomp or get hurt
            {
                var c = Critters[i];
                if (!new Rect2(c.Pos, c.Size).Intersects(pr)) continue;
                bool stomp = p.Vel.Y > 40f && (p.Pos.Y + p.Size.Y) - c.Pos.Y < 16f;
                if (stomp)
                {
                    p.Vel.Y = -420f;
                    p.Energy = Math.Min(MaxEnergy, p.Energy + 1f);
                    Burst(c.Center, new Color(0.9f, 0.5f, 0.6f), 10, 160);
                    Critters.RemoveAt(i);
                }
                else Hurt(p, 2f, true, Math.Sign(c.Center.X - p.Center.X));
            }

            foreach (var h in Hazards)   // Drain pools hurt on contact
            {
                if (h.Kind != Hazard.Drain) continue;
                if (new Rect2(h.TileX * TS, h.Row * TS - 14, TS * 2, 14).Intersects(pr))
                    Hurt(p, 3f, true, p.Facing);
            }
        }
    }

    // =====================================================================
    //  ACTIONS  (Explore / Interact / Trade)  - each costs Energy
    // =====================================================================
    static float ExploreCost(Player p) => p.Role == Role.Scout ? 1f : 2f;   // Scout: cheaper Explore

    bool Pay(Player p, float cost)
    {
        if (p.Energy < cost) { Toast($"{p.Name} needs {cost:0} Energy for that."); return false; }
        p.Energy -= cost;
        return true;
    }

    void DoExplore(Player p)
    {
        int c = ChunkOf(p.Center.X), n = Math.Clamp(c + p.Facing, 0, NC - 1);
        if (Chunks[c].Revealed && Chunks[n].Revealed) { Toast("Nothing new to explore here."); return; }
        if (!Pay(p, ExploreCost(p))) return;
        Reveal(c); Reveal(n);
    }

    void Reveal(int c)
    {
        var ch = Chunks[c];
        if (ch.Revealed) return;
        ch.Revealed = true;
        ch.Flash = 1f;
        string extra = (ch.HasBeacon ? " An Ancient Beacon is here!" : "") + (Hazards.Any(h => h.TileX / CW == c) ? " Hazard spotted!" : "");
        Toast($"Zone {c + 1} revealed: {ch.Type} (difficulty {Difficulty(ch.Type)}).{extra}");
        Burst(new Vector2((c * CW + CW / 2f) * TS, 300), new Color(0.7f, 0.9f, 1f), 14, 200);
    }

    void DoInteract(Player p)
    {
        var feet = p.Pos.Y + p.Size.Y;
        var bc = Beacons.FirstOrDefault(b => Math.Abs(b.X - p.Center.X) < 50 && Math.Abs(b.BaseY - feet) < 70);

        if (bc != null && bc.State == BeaconState.Inactive)
        {
            if (!Pay(p, 2)) return;
            bc.State = BeaconState.Active;
            p.Beacons++;
            Toast($"*** {p.Name} ACTIVATES a Beacon! ({Beacons.Count(b => b.State == BeaconState.Active)}/{BeaconCount}) ***");
            Burst(new Vector2(bc.X, bc.BaseY - 78), new Color(0.4f, 1f, 1f), 30, 260);
            CheckEnd();
            return;
        }
        if (bc != null && bc.State == BeaconState.Corrupted)
        {
            if (!Pay(p, 3)) return;
            bc.State = BeaconState.Inactive; bc.Threat = 0;
            Toast($"{p.Name} purges the corruption from the Beacon.");
            Burst(new Vector2(bc.X, bc.BaseY - 78), new Color(0.8f, 0.7f, 1f), 20, 200);
            return;
        }

        var hz = Hazards.OrderBy(h => p.Center.DistanceTo(HazCenter(h))).FirstOrDefault();
        if (hz != null && p.Center.DistanceTo(HazCenter(hz)) < 110f)
        {
            if (!Pay(p, 2)) return;
            Toast($"{p.Name} clears the {hz.Kind} hazard.");
            Burst(HazCenter(hz), new Color(1f, 0.8f, 0.4f), 14, 180);
            RemoveHazard(hz);
            return;
        }

        int c = ChunkOf(p.Center.X);
        var ch = Chunks[c];
        if (ch.Stabilized) { Toast("This zone is already stable."); return; }
        bool free = p.Role == Role.Engineer && !p.FreeStabUsed;   // Engineer: 1 free stabilize
        if (free) p.FreeStabUsed = true; else if (!Pay(p, 2)) return;
        ch.Stabilized = true;
        ch.Flash = 1f;
        Toast($"{p.Name} stabilizes Zone {c + 1}" + (free ? " for free (Engineer)." : ".") + Clue(p));
        Burst(p.Center, new Color(0.4f, 0.85f, 1f), 16, 180);
    }

    string Clue(Player p)
    {
        var dormant = Beacons.Where(b => b.State != BeaconState.Active).ToList();
        if (dormant.Count == 0) return "";
        var n = dormant.OrderBy(b => Math.Abs(b.X - p.Center.X)).First();
        int tiles = (int)(Math.Abs(n.X - p.Center.X) / TS);
        return $" Clue: nearest Beacon is {tiles} blocks {(n.X > p.Center.X ? "to the right" : "to the left")}.";
    }

    void DoGive(Player p)
    {
        var o = Players.FirstOrDefault(q => q != p && q.Center.DistanceTo(p.Center) < 96f);
        if (o == null) { Toast("No teammate close enough to trade."); return; }
        if (p.Traded || p.Energy < 3f) { Toast("Can't trade right now."); return; }
        p.Energy -= 2; o.Energy = Math.Min(MaxEnergy, o.Energy + 2); p.Traded = true;
        Toast($"{p.Name} gives 2 Energy to {o.Name}.");
        Burst(o.Center, new Color(1f, 0.9f, 0.4f), 10, 120);
    }

    // =====================================================================
    //  TURN PHASES
    // =====================================================================
    void PlanNext()
    {
        NextShifts.Clear(); NextHazards.Clear();
        var pool = Enumerable.Range(1, NC - 1).Where(c => !Chunks[c].Stabilized).OrderBy(_ => _rng.Next()).Take(3);
        foreach (int c in pool)
        {
            var opts = Enum.GetValues<TileType>().Where(t => t != Chunks[c].Type).ToArray();
            NextShifts.Add((c, opts[_rng.Next(opts.Length)]));
        }
        var dormant = Beacons.Where(b => b.State == BeaconState.Inactive).ToList();
        for (int i = 0; i < 2; i++)
        {
            int c = (dormant.Count > 0 && _rng.NextDouble() < 0.35) ? dormant[_rng.Next(dormant.Count)].Chunk : _rng.Next(1, NC);
            NextHazards.Add((c, _rng.Next(2) == 0 ? Hazard.Drain : Hazard.Block));
        }
    }

    void ShiftPhase()
    {
        foreach (var s in NextShifts)
        {
            var ch = Chunks[s.chunk];
            if (ch.Stabilized) continue;
            ch.Type = s.type;
            GenerateChunk(s.chunk); GenerateFruits(s.chunk); GenerateCritters(s.chunk); RehomeHazards(s.chunk);
            if (ch.Revealed) { ch.Flash = 1f; Toast($"Zone {s.chunk + 1} shifted to {s.type}!"); }
        }
        foreach (var p in Players) { Unstick(p); p.Traded = false; }
        foreach (var h in NextHazards)
        {
            if (Chunks[h.chunk].Stabilized) continue;
            SpawnHazard(h.chunk, h.kind, Beacons.Any(b => b.Chunk == h.chunk && b.State == BeaconState.Inactive));
        }
        PlanNext();
    }

    Vector2 HazCenter(Haz h) => h.Kind == Hazard.Drain
        ? new Vector2(h.TileX * TS + TS, h.Row * TS - 7)
        : new Vector2(h.TileX * TS + TS / 2f, h.Row * TS - 80);

    void SpawnHazard(int chunk, Hazard kind, bool atBeacon)
    {
        int x0 = chunk * CW;
        for (int tries = 0; tries < 40; tries++)
        {
            int col = atBeacon ? 3 + _rng.Next(0, 4) : 1 + _rng.Next(0, CW - 3);
            int tx = x0 + col, row = GroundTop[tx];
            if (row >= H) continue;
            if (kind == Hazard.Drain && GroundTop[tx + 1] != row) continue;
            var hz = new Haz { Kind = kind, TileX = tx, Row = row };
            var cen = HazCenter(hz);
            if (Players.Any(p => p.Center.DistanceTo(cen) < 120f)) continue;
            if (Hazards.Any(o => Math.Abs(o.TileX - tx) < 4)) continue;
            Hazards.Add(hz);
            if (kind == Hazard.Block) PlaceBarrier(hz);
            Toast(Chunks[chunk].Revealed ? $"A {kind} hazard appeared in Zone {chunk + 1}!" : "Something stirs in the fog...");
            return;
        }
    }

    void PlaceBarrier(Haz h) { for (int r = h.Row - 5; r < h.Row; r++) if (r >= 0) Tiles[h.TileX, r] = 3; }

    void RemoveHazard(Haz h)
    {
        if (h.Kind == Hazard.Block)
            for (int r = 0; r < H; r++) if (Tiles[h.TileX, r] == 3) Tiles[h.TileX, r] = 0;
        Hazards.Remove(h);
    }

    void RehomeHazards(int c)
    {
        foreach (var h in Hazards.Where(x => x.TileX / CW == c).ToList())
        {
            int row = GroundTop[h.TileX];
            bool ok = row < H && (h.Kind != Hazard.Drain || GroundTop[h.TileX + 1] == row);
            if (!ok) { Hazards.Remove(h); continue; }
            h.Row = row;
            if (h.Kind == Hazard.Block) PlaceBarrier(h);
        }
    }

    void HazardPhase()
    {
        // Hazards trigger: Drain = Energy loss, Block = Energy loss + forced movement
        foreach (var p in Players)
            foreach (var h in Hazards)
            {
                var cen = HazCenter(h);
                if (p.Center.DistanceTo(cen) > 130f) continue;
                if (h.Kind == Hazard.Drain) { Hurt(p, 2f, false, 0, true); Toast($"{p.Name} is caught in a Drain surge!"); }
                else
                {
                    p.Vel.X = Math.Sign(p.Center.X - cen.X) * 520f; p.Stun = 0.3f;
                    Hurt(p, 1f, false, 0, true);
                    Toast($"{p.Name} is shoved back by the thorns!");
                }
            }

        // Hazards near a dormant Beacon corrupt it after 2 turns
        foreach (var b in Beacons)
        {
            if (b.State != BeaconState.Inactive) continue;
            bool near = Hazards.Any(h => h.TileX / CW == b.Chunk && Math.Abs(HazCenter(h).X - b.X) <= 4 * TS);
            if (near)
            {
                b.Threat++;
                if (b.Threat >= 2)
                {
                    b.State = BeaconState.Corrupted; b.Threat = 0;
                    foreach (var hh in Hazards.Where(x => x.TileX / CW == b.Chunk).ToList()) RemoveHazard(hh);
                    Toast(Chunks[b.Chunk].Revealed ? $"The Beacon in Zone {b.Chunk + 1} is CORRUPTED!" : "A distant Beacon flickers and goes dark...");
                }
            }
            else b.Threat = 0;
        }

        // Old hazards fade (unless guarding a Beacon)
        foreach (var h in Hazards.ToList())
        {
            h.Age++;
            bool guarding = Beacons.Any(b => b.State == BeaconState.Inactive && b.Chunk == h.TileX / CW);
            if (h.Age >= 3 && !guarding) RemoveHazard(h);
        }
    }

    void RestPhase()
    {
        foreach (var p in Players) p.Energy = Math.Min(MaxEnergy, p.Energy + 1f);
        Toast("Rest Phase: everyone regains 1 Energy.");
    }

    // =====================================================================
    //  WIN / LOSS
    // =====================================================================
    bool CheckEnd()
    {
        if (_state != GameState.Playing) return true;
        int active = Beacons.Count(b => b.State == BeaconState.Active);

        bool win = _mode == GameMode.Competitive
            ? Players.Any(p => p.Beacons >= 2)
            : active == BeaconCount && (_mode != GameMode.Solo || Players[0].Energy > 0.01f);
        if (win)
        {
            Finish(GameState.Victory, _mode == GameMode.Competitive
                ? $"{Players.First(p => p.Beacons >= 2).Name} activated two Beacons first!"
                : "All Ancient Beacons are active!");
            return true;
        }
        if (Beacons.All(b => b.State == BeaconState.Corrupted)) { Finish(GameState.Defeat, "All Beacons were corrupted."); return true; }
        if (Players.All(p => p.Energy <= 0.01f)) { Finish(GameState.Defeat, "Out of Energy."); return true; }
        return false;
    }

    void Finish(GameState s, string reason)
    {
        _state = s;
        _endReason = reason;
    }

    // =====================================================================
    //  CAMERA / FX / HELPERS
    // =====================================================================
    void UpdateCamera(float dt)
    {
        if (Players.Count == 0) return;
        float mid = Players.Average(p => p.Center.X);
        float target = Mathf.Clamp(mid - ViewW / 2f, 0, W * TS - ViewW);
        _camX = Mathf.Lerp(_camX, target, 1f - Mathf.Exp(-6f * dt));

        if (Players.Count > 1)   // keep both players on screen
            foreach (var p in Players)
            {
                float nx = Mathf.Clamp(p.Pos.X, _camX + 4, _camX + ViewW - p.Size.X - 4);
                if (Math.Abs(nx - p.Pos.X) > 0.01f) { p.Pos.X = nx; p.Vel.X = 0; Unstick(p); }
            }

        var zone = Chunks[ChunkOf(_camX + ViewW / 2f)];
        Color tgt = !zone.Revealed ? new Color(0.2f, 0.22f, 0.32f) : zone.Type switch
        {
            TileType.Forest => new Color(0.45f, 0.75f, 0.95f),
            TileType.Ruins => new Color(0.85f, 0.58f, 0.45f),
            TileType.Hills => new Color(0.6f, 0.82f, 0.8f),
            _ => new Color(0.08f, 0.06f, 0.14f),
        };
        _sky = _sky.Lerp(tgt, Math.Min(1f, 3f * dt));
    }

    void Burst(Vector2 pos, Color c, int n, float spd)
    {
        for (int i = 0; i < n; i++)
        {
            float a = (float)(_rng.NextDouble() * Math.Tau);
            float s = spd * (0.3f + (float)_rng.NextDouble() * 0.7f);
            Particles.Add(new Particle { Pos = pos, Vel = new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * s, Life = 0.7f, MaxLife = 0.7f, Size = 2f + (float)_rng.NextDouble() * 3f, Color = c });
        }
    }

    void UpdateParticles(float dt)
    {
        foreach (var p in Particles) { p.Life -= dt; p.Vel.Y += 400f * dt; p.Pos += p.Vel * dt; }
        Particles.RemoveAll(p => p.Life <= 0);
    }

    void Toast(string text)
    {
        Toasts.Add(new ToastMsg { Text = text, T = 5f });
        if (Toasts.Count > 6) Toasts.RemoveAt(0);
    }
}
