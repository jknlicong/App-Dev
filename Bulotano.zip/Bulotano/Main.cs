using Godot;
using System.Collections.Generic;

/// <summary>Title menu. Starts a GameWorld (the platformer) and returns here on Esc.</summary>
public partial class Main : Control
{
    GameWorld _world;
    Control _menu;
    OptionButton _modeOpt, _r1, _r2;

    public override void _Ready()
    {
        var bg = new ColorRect { Color = new Color(0.07f, 0.08f, 0.14f), MouseFilter = MouseFilterEnum.Ignore };
        bg.SetAnchorsPreset(LayoutPreset.FullRect);
        AddChild(bg);
        BuildMenu();
    }

    void BuildMenu()
    {
        var center = new CenterContainer();
        center.SetAnchorsPreset(LayoutPreset.FullRect);
        AddChild(center);
        _menu = center;

        var box = new VBoxContainer { CustomMinimumSize = new Vector2(460, 0) };
        box.AddThemeConstantOverride("separation", 10);
        center.AddChild(box);

        var title = new Label { Text = "SHIFTING BEACONS", HorizontalAlignment = HorizontalAlignment.Center };
        title.AddThemeFontSizeOverride("font_size", 44);
        box.AddChild(title);
        box.AddChild(new Label { Text = "Run, jump and activate the 3 Ancient Beacons before the world collapses!", HorizontalAlignment = HorizontalAlignment.Center });

        _modeOpt = new OptionButton();
        foreach (var m in new[] { "Solo", "Co-op (2 players)", "Competitive (2 players)" }) _modeOpt.AddItem(m);
        box.AddChild(Row("Mode", _modeOpt));

        _r1 = RoleOption(); box.AddChild(Row("Player 1 role", _r1));
        _r2 = RoleOption(); box.AddChild(Row("Player 2 role", _r2));

        var start = new Button { Text = "Start Adventure" };
        start.Pressed += StartGame;
        box.AddChild(start);

        box.AddChild(new Label
        {
            Text = "Scout: cheaper Explore | Guardian: less hazard damage\n" +
                   "Engineer: 1 free stabilize | Oracle: sees upcoming shifts & hazards\n\n" +
                   "Solo: A/D or arrows, W/Space jump, E explore, F interact\n" +
                   "2 players: P1 = A/D/W/E/F/Q   P2 = Arrows + , . /",
            HorizontalAlignment = HorizontalAlignment.Center
        });
    }

    OptionButton RoleOption()
    {
        var o = new OptionButton();
        foreach (var r in new[] { "Scout", "Guardian", "Engineer", "Oracle" }) o.AddItem(r);
        return o;
    }

    HBoxContainer Row(string label, Control c)
    {
        var row = new HBoxContainer();
        row.AddChild(new Label { Text = label, CustomMinimumSize = new Vector2(140, 0) });
        c.SizeFlagsHorizontal = SizeFlags.ExpandFill;
        row.AddChild(c);
        return row;
    }

    void StartGame()
    {
        var mode = (GameMode)_modeOpt.Selected;
        var roles = new List<Role> { (Role)_r1.Selected };
        if (mode != GameMode.Solo) roles.Add((Role)_r2.Selected);

        _world?.QueueFree();
        _world = new GameWorld();
        AddChild(_world);
        _world.BackToMenu += ShowMenu;
        _world.Start(mode, roles);
        _menu.Visible = false;
    }

    void ShowMenu()
    {
        _world?.QueueFree();
        _world = null;
        _menu.Visible = true;
    }
}
