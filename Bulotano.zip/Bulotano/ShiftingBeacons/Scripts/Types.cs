using Godot;

public enum TileType { Forest, Ruins, Hills, Caverns }
public enum Hazard { None, Drain, Block }
public enum BeaconState { Inactive, Active, Corrupted }
public enum Role { Scout, Guardian, Engineer, Oracle }
public enum GameMode { Solo, Coop, Competitive }
public enum GameState { Playing, Victory, Defeat }

/// <summary>Anything that moves and collides with the tile grid (top-left position).</summary>
public class Body
{
    public Vector2 Pos, Vel, Size;
    public bool OnGround, HitWall;
    public Vector2 Center => Pos + Size / 2f;
}

public class Bind { public Key[] Left, Right, Jump, Explore, Interact, Give; }

public class Player : Body
{
    public string Name;
    public Role Role;
    public Bind Bind;
    public float Energy;
    public int Facing = 1;
    public float Coyote, JumpBuf, Invuln, Stun, ActCd, Anim, SafeT;
    public int Beacons;
    public bool FreeStabUsed, Traded, Exhausted;
    public Vector2 SafePos;
}

public class Critter : Body { public int Dir = 1; }

public class Fruit { public Vector2 Pos; public float Phase; }

/// <summary>A hazard standing on the ground. Drain = energy pool, Block = thorn wall.</summary>
public class Haz
{
    public Hazard Kind;
    public int TileX, Row, Age;
}

public class BeaconEnt
{
    public int Chunk;
    public float X, BaseY;
    public BeaconState State = BeaconState.Inactive;
    public int Threat;
}

/// <summary>One "tile" of the lab world: a 10-column zone of the level.</summary>
public class Chunk
{
    public TileType Type;
    public bool Revealed, Stabilized, HasBeacon;
    public float Flash;
}

public class Particle
{
    public Vector2 Pos, Vel;
    public float Life, MaxLife, Size;
    public Color Color;
}

public class ToastMsg { public string Text; public float T; }
